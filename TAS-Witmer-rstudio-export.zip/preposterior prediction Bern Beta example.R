#Preposterior predictive analysis/marginal distn of z: Does the prior give rise to reasonable data?
#Example: theta = % veggies at OC
#source("DBDA2E-utilities.R")
source("BetaPlot.R")
source("Beta selection and graphing.R", echo=TRUE)
myMode = 0.2
myKappa = 20
BetaPlot(betaABfromModeKappa(myMode,myKappa)$a,betaABfromModeKappa(myMode,myKappa)$b) #see plot along with a and b
#So the prior to consider is Be(4.6,15.4)
#But does such a prior give rise to reasonable data in samples of size 25, say?
a = 4.6; b = 15.4 #specify the beta(a,b) parameters
theta = rbeta(2000, a, b) #generate 2000 thetas from that beta prior
z = rbinom(n=2000, size=25, prob=theta) #simulate 2000 data points, each from a Binomial(25,theta)
#=Note that each of the 2000 thetas is used once
c(mean(z), sd(z))
hist(z,breaks=seq(from=-0.5,to=max(z)+0.5))
