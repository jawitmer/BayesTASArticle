BetaPlot = function( a,b ) {
  # Construct grid of theta values, used for graphing.
  binwidth = 0.005 # Arbitrary small value for comb on Theta.
  Theta = seq( from = binwidth/2 , to = 1-(binwidth/2) , by = binwidth )
  # Compute the prior at each value of theta.
  pTheta = dbeta( Theta , a , b )
  layout( matrix( 1 )) # 1x1 panel
  par( mar=c(4,5,1,1)  ) # margin specs
  maxY = max( pTheta ) # max y for plotting
  # Plot the prior.
  plot( Theta , pTheta , type="l" , lwd=3 ,
        xlim=c(0,1) , ylim=c(0,maxY) , cex.axis=1.2 ,
        xlab=bquote(theta) , ylab=bquote(p(theta)) , cex.lab=1.5 )
  if ( a > b ) { textx = 0 ; textadj = c(0,1) } 
  else { textx = 1 ; textadj = c(1,1) }
  text( textx , 1.0*max(pTheta) ,
        bquote( "beta(" * theta * "|" * .(a) * "," * .(b) * ")"  ) ,
        cex=2.0 ,adj=textadj )
          #return( postShape )
} # end of function
##Use: enter BetaPlot(2,3) or something similar
