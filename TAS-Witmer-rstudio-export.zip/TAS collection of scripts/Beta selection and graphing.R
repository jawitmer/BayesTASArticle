#Playing with Beta(a,b) distributions
source("DBDA2E-utilities.R")
source("BetaPlot.R")

betaABfromMeanKappa(.6,7) #input mean, kappa and get back a and b
betaABfromModeKappa(.6,7) #input mode, kappa and get back a and b

myMode = 0.6
myKappa = 7
BetaPlot(betaABfromModeKappa(myMode,myKappa)$a,betaABfromModeKappa(myMode,myKappa)$b) #see plot along with a and b

myMean = 0.5
myKappa = 7
BetaPlot(betaABfromMeanKappa(myMean,myKappa)$a,betaABfromMeanKappa(myMean,myKappa)$b) #see plot along with a and b
